﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TestNeiro.Checkers;

namespace TestNeiro
{
    public interface IStrategy
    {
        string GetMove(IList<FieldItem> FieldItems, FieldValueType player);
    }
    class Strategy : IStrategy
    {
        private IEnumerable<IChecker> _checkers = null;
        public Strategy()
        {
            _checkers = CheckerFactory.Instance.GetCheckers();

        }
        public string GetMove(IList<FieldItem> FieldItems, FieldValueType player)
        {
            IList<FieldItem> fields = new List<FieldItem>();

            foreach(var item in FieldItems)
            {
                fields.Add(item);
            }

            var checkResult = _checkers.Select(ch => ch.Check(FieldItems)).ToList();

            return null;
        }

    }
}
