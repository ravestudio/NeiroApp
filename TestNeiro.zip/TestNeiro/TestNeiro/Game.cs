﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestNeiro
{
    public class Game
    {
        public IList<FieldItem> FieldItems { get; set; }

        public FieldValueType myRole { get; set; }

        private IStrategy _gameStrategy = null;

        public Game(IStrategy gameStrategy)
        {

            this._gameStrategy = gameStrategy;

            this.FieldItems = new List<FieldItem>();

            this.myRole = FieldValueType.O;

            for(int x = 0; x<3; x++)
            {
                for (int y = 0; y < 3; y++)
                {
                    this.FieldItems.Add(new FieldItem() { PosX = x, PosY = y, Value =  FieldValueType.emty });
                }
            }

            Set(0, 0, FieldValueType.O);
            Set(0, 1, FieldValueType.O);
            Set(0, 2, FieldValueType.O);



            _gameStrategy.GetMove(FieldItems, myRole);
        }

        private void Set(int y, int x, FieldValueType value)
        {
            var item = this.FieldItems.Single(i => i.PosY == y && i.PosX == x);

            item.Value = value;
        }
    
    }
}
