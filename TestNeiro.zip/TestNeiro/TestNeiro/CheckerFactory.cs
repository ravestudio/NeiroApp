﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TestNeiro.Checkers;

namespace TestNeiro
{
    public class CheckerFactory
    {
        private static CheckerFactory _instance = null;
        public static CheckerFactory Instance
        {
            get
            {
                return _instance ?? new CheckerFactory();
            }
        }

        public CheckerFactory()
        {

        }

        public IEnumerable<IChecker> GetCheckers()
        {
            IList<IChecker> _checkers = new List<IChecker>();

            //horisontal checker
            _checkers.Add(new Checkers.Checker((items) =>
            {
                FieldValueType? result = null;

                for (int y = 0; y < 3; y++)
                {
                    int res = 0;
                    FieldValueType? compare = items.Single(i => i.PosX == 0 && i.PosY == y).Value;

                    if (compare == null) continue;

                    for (int x = 1; x < 3; x++)
                    {
                        var item = items.Single(i => i.PosX == x && i.PosY == y);

                        res += item.Value == compare ? 1 : 0;
                    }

                    if (res == 2)
                    {
                        result = compare;
                        break;
                    }
                }

                return result;
            }));

            //vertical checker
            _checkers.Add(new Checkers.Checker((items) =>
            {
                FieldValueType? result = null;

                for (int x = 0; x < 3; x++)
                {
                    int res = 0;
                    FieldValueType? compare = items.Single(i => i.PosX == x && i.PosY == 0).Value;

                    if (compare == null) continue;

                    for (int y = 1; y < 3; y++)
                    {
                        var item = items.Single(i => i.PosX == x && i.PosY == y);

                        res += item.Value == compare ? 1 : 0;
                    }

                    if (res == 2)
                    {
                        result = compare;
                        break;
                    }
                }

                return result;
            }));

            //diagonal checker
            _checkers.Add(new Checkers.Checker((items) =>
            {
                FieldValueType? result = null;

                for (int g = 0; g < 3; g += 2)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        int res = 0;
                        FieldValueType? compare = items.Single(i => i.PosX == j && i.PosY == Math.Abs(g-j)).Value;

                        if (compare == null) break;

                        var item = items.Single(i => i.PosX == j && i.PosY == j);

                        res += item.Value == compare ? 1 : 0;

                        if (res == 3)
                        {
                            result = compare;
                        }
                    }
                }

                return result;
            }));

            return _checkers;
        }
    }
}
