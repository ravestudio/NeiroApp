﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestNeiro
{
    public struct FieldItem
    {
        public int PosX { get; set; }
        public int PosY { get; set; }
        public FieldValueType Value { get; set; }

    }

    public enum FieldValueType
    {
        emty, X, O
    }
}
