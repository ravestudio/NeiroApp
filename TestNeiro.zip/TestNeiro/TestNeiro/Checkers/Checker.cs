﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestNeiro.Checkers
{
    public class Checker : IChecker
    {
        public Checker(Func<IList<FieldItem>, FieldValueType?> func)
        {
            this.Check = func;
        }
        public Func<IList<FieldItem>, FieldValueType?> Check { get; private set; }
    }
}
