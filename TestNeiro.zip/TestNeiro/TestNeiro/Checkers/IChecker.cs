﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestNeiro.Checkers
{
    public interface IChecker
    {
        Func<IList<FieldItem>, FieldValueType?> Check {get;}
    }
}
